(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/server.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('thePlayers', function () {                             // 1
  var currentUserId = this.userId;                                     // 2
  return PlayersList.find({ createdBy: currentUserId });               // 3
});                                                                    //
Meteor.methods({                                                       // 5
  'insertPlayerData': function (userName) {                            // 6
    var currentUserId = Meteor.userId();                               // 7
    PlayersList.insert({                                               // 8
      name: userName,                                                  // 9
      score: 0,                                                        // 10
      createdBy: currentUserId                                         // 11
    });                                                                //
  },                                                                   //
  'removePlayerData': function (userId) {                              // 14
    var currentUserId = Meteor.userId();                               // 15
    PlayersList.remove({ _id: userId, createdBy: currentUserId });     // 16
  },                                                                   //
  'updatePlayerData': function (userId, num) {                         // 18
    var currentUserId = Meteor.userId();                               // 19
    PlayersList.update({ _id: userId, createdBy: currentUserId }, { $inc: { score: num } });
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.js.map
